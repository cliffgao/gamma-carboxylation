Jianzhao Gao Ning Zhang and Jishou Ruan, Copyright (C) 2013
This file describes how to work with  CarboxySVM (V1.0 Beta)
2013-09-04
------------------------------------------------
=====
CarboxySVM (V1.0 Beta)

CarboxySVM is written by Python 2.6.  
The original program was compiled on a Linux system (Ubuntu 11.04) 

========

run the CarboxySVM.sh

type:
./CarboxySVM.sh  ./data/eg.fa  ./data/eg.21.fa

results are in the ./outputs/out.txt

If you want to run the prediction on the other datasets, please follow the steps:

(1) get the sliding windows of the gamma-carboxylation sites
./bin/sliding_features_21.py  fasta_file  fw_n
where
fasta_file: protein sequence in fasta format.
fw_n: the carboxylation sites are in the sliding windows of the size 21.
in fw_n:
"""
>P81755_51
RTIRTRLNIRECCEDGWCCTA
>P81755_54
RTRLNIRECCEDGWCCTAAPL
"""

(2) run the BLAST, DISOPRED, PSIPRED, REAL SPINE for fw_n.



(3)Run the blast, and copy the pssm file in ./data/pssm/   
each pssm file should be "*.pssm", where * is protein ID.

(4) Copy the results (named disorder.ss.dat) from PSIPRED 
and DISOPRED into ./data/disorder-ss/
the file is like this:
"""
>P81755_51
RTIRTRLNIRECCEDGWCCTA
CEEEEHHHHHHHHCCCCEEEC
**...................
"""
where 1st line is ID; 2nd line is protein segment; 
3rd line is predicted secondary structure;
4th line is the predicted disorder from DISOPRED.

(5)Copy the results (named rsa.dat ) from Real Spine into ./data/rsa/
the file is like this :
"""
>P81755_51
RTIRTRLNIRECCEDGWCCTA
0.59336,0.47527,0.32557,...,0.47468,
111111110110011000011
"""
where 1st line is ID; 2nd line is protein segment; 
3rd line is predicted relative solvent accessibility values;
4th line is the annotation of buried (0) or exposed (1). if the value > 0.25 annotated 1 else annotated 0.

(6) Then type

./CarboxySVM.sh  fasta_f  fw_n
where fasta_f and fw_n is as same as (1)

=====

install DISOPRED (v2.4)

http://bioinfadmin.cs.ucl.ac.uk/downloads/DISOPRED/

===== 
install Real Spine (v3.0)

http://sparks.informatics.iupui.edu/Publications_files/publication.htm

=====
install PSIPRED (v3.3)

http://bioinfadmin.cs.ucl.ac.uk/downloads/psipred/
=====

install BLAST 
http://www.ncbi.nih.gov/blast/download.shtml

=====
FEEDBACK
If you have any feedback, contact Jianzhao Gao at gaojz@nankai.edu.cn. 
or Ning Zhang   at zhni@tju.edu.cn


=====
REFERENCE

E. Faraggi, B. Xue, and Y. Zhou, Improving the prediction accuracy of residue solvent accessibility and real-value backbone torsion
angles of proteins by fast guided-learning through a two-layer neural network.,Proteins 74, 857-871 (2009)

Chih-Chung Chang and Chih-Jen Lin, LIBSVM : a library for support vector machines. ACM Transactions on Intelligent Systems and Technology, 2:27:1--27:27, 2011. Software available at http://www.csie.ntu.edu.tw/~cjlin/libsvm 

McGuffin L.J., Bryson K., Jones D.T., 2000. The PSIPRED protein structure prediction server. Bioinformatics. 16, 404-405.

Ward J.J., Sodhi J.S., McGuffin L.J., Buxton B.F., Jones D.T., 2004. Prediction and functional analysis of native disorder in proteins from the three kingdoms of life. J. Mol. Biol. 337, 635-645.
