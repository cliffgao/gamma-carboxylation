#---

if [ $# -lt 2 ]
then
	echo "Usage: CarboxySVM.sh  fasta_file  win_fa"
	echo "example:"
	echo "./CarboxySVM.sh  ./data/eg.fa  ./data/eg.21.fa"

else

fr_n=$1
win_fa=$2
#echo "fr_n"
#fr_n="./data/eg.fa"
#win_fa="./data/eg.21.fa"


data="./data/"

disorder_ss_data="./data/disorder-ss/disorder.ss.dat"
rsa_data="./data/rsa/rsa.dat"
pssm_f="./data/pssm/"

select_feature_id="./model/train.select.features.id"
tr_model="./model/train.select.libsvm.model"

idx_f=${win_fa}".idx"
label_f=${win_fa}".label"


fdir="./features/"
exedir="./bin/"
outdir="./outputs/"

model_csv=${fdir}"all.features.csv"
label_model_csv=${fdir}"all.features.model.csv"
test_select_svm=${outdir}"test.svm"

svmPredict="./model/svm-predict"
svmout=${outdir}"tmp.svm.out.txt"
outfile=${outdir}"out.txt"

${exedir}sliding_features_21.py  ${fr_n}  ${win_fa}

mkdir ${fdir}
# get the features of aa and 49 properties # order by lipp.represent.idx
##:<<BLOCK
${exedir}aa.49.v2.py  ${win_fa}  ${fdir}aa49.csv
# get the pssm features
${exedir}pssm.feature.v2.py  ${pssm_f}  ${idx_f}  ${fdir}pssm.csv

#get the ss features
${exedir}ss.features.v2.py  ${disorder_ss_data}   ${fdir}ss.csv

# get the dis features
${exedir}dis.features.v2.py  ${disorder_ss_data}   ${fdir}dis.csv

# get the rsa features
${exedir}rsa.features.v2.py  ${rsa_data}   ${fdir}rsa.csv

#paste for csv files
paste -d "" ${fdir}aa49.csv  ${fdir}pssm.csv ${fdir}ss.csv  ${fdir}dis.csv  ${fdir}rsa.csv >${model_csv}

# add the label
paste -d "," ${label_f}   ${model_csv}   > ${label_model_csv}

${exedir}csv2svm.py  ${label_model_csv}   
${exedir}sweep_svm_model.py  ${label_model_csv}".svm"   ${test_select_svm} ${select_feature_id}  col

#predic the carboxylate sites
${svmPredict}  ${test_select_svm}  ${tr_model}  ${svmout}

${exedir}show.predicts.py  ${fr_n} ${outfile} ${svmout}  ${win_fa}

rm -r ${fdir}
rm ${outdir}tmp*
rm ${idx_f}
rm ${label_f}
echo "output: ./outputs/out.txt"
##BLOCK
fi
